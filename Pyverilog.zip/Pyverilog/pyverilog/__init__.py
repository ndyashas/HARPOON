from __future__ import absolute_import
from __future__ import print_function

import os

__version__ = open(os.path.join(os.path.dirname(__file__), "VERSION")).read().splitlines()[0]
